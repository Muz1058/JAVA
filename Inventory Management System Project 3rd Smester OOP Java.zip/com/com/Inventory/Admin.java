package com.Inventory;


import java.io.*;
import java.util.ArrayList;
import java.util.Scanner;

class Admin extends User {
    String defaultID = "Admin1";
    String defaultPassword = "Admin1";
    Scanner input = new Scanner(System.in);
    ArrayList<Supplier> suppliers;
    public Admin() {
        super();
    }

    public void Login() {
        System.out.println("Enter ID: ");
        String id = input.nextLine();
        System.out.println("Enter Password: ");
        String password = input.nextLine();
        if (authenticate(id, password)) {
            System.out.println("Logged in Successfully!");
            viewDashboard();
        } else {
            System.out.println("Error: ID or Password doesn't matched!");
        }
    }

    // method to authenticate admin:
    public boolean authenticate(String ID, String Password) {
        return (ID.equals(defaultID) && Password.equals(defaultPassword));
    }

    public Admin(String userID, String name, String email, String password, String role) {
        super(userID, name, email, password, role);
    }


    public void addEmployee() {
        System.out.print("Enter employee ID: ");
        String employeeID = input.nextLine();
        System.out.print("Enter employee name: ");
        String employeeName = input.nextLine();
        System.out.print("Enter employee email: ");
        String employeeEmail = input.nextLine();
        System.out.print("Enter employee password: ");
        String employeePassword = input.nextLine();
        System.out.print("Enter employee role: ");
        String employeeRole = input.nextLine();
        Employee employee = new Employee(employeeID, employeeName, employeeEmail, employeePassword, employeeRole);
        try (BufferedWriter writer = new BufferedWriter(new FileWriter("Employees.txt", true))) {
            String data = "\n" + employee.getUserID() + "," + employee.getName() + "," + employee.getEmail() + "," + employee.getPassword() + "," + employee.getRole();
            writer.write(data);
            writer.newLine();
            System.out.println("Employee added successfully!");
        } catch (IOException e) {
            System.out.println("Error adding employee: " + e.getMessage());
        }
    }


    public void removeEmployee(String userID) {
        try (BufferedReader reader = new BufferedReader(new FileReader("Employees.txt"))) {
            String line;
            StringBuilder updatedData = new StringBuilder();
            boolean employeeFound = false;
            while ((line = reader.readLine()) != null) {
                String[] data = line.split(",");
                if (!data[0].equals(userID)) {
                    updatedData.append(line).append("\n");
                } else {
                    employeeFound = true;
                }
            }
            if (employeeFound) {
                try (BufferedWriter writer = new BufferedWriter(new FileWriter("Employees.txt"))) {
                    writer.write(updatedData.toString());
                    System.out.println("Employee removed successfully!");
                } catch (IOException e) {
                    System.out.println("Error removing employee: " + e.getMessage());
                }
            } else {
                System.out.println("Employee not found!");
            }
        } catch (IOException e) {
            System.out.println("Error reading file: " + e.getMessage());
        }
    }

    public void addSupplier() {
        System.out.print("Enter supplier ID: ");
        String supplierID = input.nextLine();
        System.out.print("Enter supplier name: ");
        String supplierName = input.nextLine();
        System.out.print("Enter supplier email: ");
        String supplierEmail = input.nextLine();
        System.out.print("Enter supplier phone: ");
        String supplierPhone = input.nextLine();
        System.out.print("Enter supplier address: ");
        String supplierAddress = input.nextLine();
        System.out.print("Enter supplier product categories: ");
        String supplierProductCategories = input.nextLine();
        System.out.print("Enter supplier performance history: ");
        String supplierPerformanceHistory = input.nextLine();
      //  Supplier supplier=new Supplier(supplierID,supplierPerformanceHistory,supplierProductCategories,supplierAddress,supplierPhone,supplierEmail,supplierName,)
        try (BufferedWriter writer = new BufferedWriter(new FileWriter("Suppliers.txt", true))) {
            String data = supplierID + "," + supplierName + "," + supplierEmail + "," + supplierPhone + "," + supplierAddress + "," + supplierProductCategories + "," + supplierPerformanceHistory;
            writer.write(data);
            writer.newLine();
            System.out.println("Supplier added successfully!");
        } catch (IOException e) {
            System.out.println("Error adding supplier: " + e.getMessage());
        }
    }

    public void removeSupplier(String supplierID) {
        try (BufferedReader reader = new BufferedReader(new FileReader("Suppliers.txt"))) {
            String line;
            StringBuilder updatedData = new StringBuilder();
            boolean supplierFound = false;
            while ((line = reader.readLine()) != null) {
                String[] data = line.split(",");
                if (!data[0].equals(supplierID)) {
                    updatedData.append(line).append("\n");
                } else {
                    supplierFound = true;
                }
            }
            if (supplierFound) {
                try (BufferedWriter writer = new BufferedWriter(new FileWriter("Suppliers.txt"))) {
                    writer.write(updatedData.toString());
                    System.out.println("Supplier removed successfully!");
                } catch (IOException e) {
                    System.out.println("Error removing supplier: " + e.getMessage());
                }
            } else {
                System.out.println("Supplier not found!");
            }
        } catch (IOException e) {
            System.out.println("Error reading file: " + e.getMessage());
        }
    }

    Inventory inventory = new Inventory();

    public void viewSuppliers() {
        inventory.readAllSuppliersFromFile();
    }


    public void viewEmployees() {
        inventory.displayAllEmployeesFromFile();
    }

    public void viewDashboard() {
        Scanner scanner = new Scanner(System.in);
        String continueInput;
        do {
            System.out.println("Admin Dashboard");
            System.out.println("-----------------");
            System.out.println("1. Add Employee");
            System.out.println("2. Remove Employee");
            System.out.println("3. View Employees");
            System.out.println("4. Add Supplier");
            System.out.println("5. Remove Supplier");
            System.out.println("6. View Suppliers");
            System.out.println("7. Logout");
            System.out.println("-----------------");
            scanner = new Scanner(System.in);
            System.out.print("Enter your choice: ");
            int choice = scanner.nextInt();
            scanner.nextLine();
            switch (choice) {
                case 1:
                    addEmployee();
                    break;
                case 2:
                    System.out.print("Enter employee ID to remove: ");
                    String removeEmployeeID = scanner.nextLine();
                    removeEmployee(removeEmployeeID);
                    System.out.println("Employee with ID " + removeEmployeeID + " is Removed!");
                    break;
                case 3:
                    viewEmployees();
                    break;
                case 4:
                    addSupplier();
                    break;
                case 5:
                    System.out.print("Enter Supplier ID to remove: ");
                    String removeSupplierID = scanner.nextLine();
                    removeEmployee(removeSupplierID);
                    System.out.println("Supplier with ID " + removeSupplierID + " is Removed!");
                    break;
                case 6:
                    viewSuppliers();
                    break;
                case 7:
                    System.out.println("Logging out...");
                    System.exit(0);
                    break;
                default:
                    System.out.println("Invalid choice!");
            }
            System.out.println("Do you want to continue? (y/n)");
            continueInput = scanner.nextLine();
        } while (continueInput.equalsIgnoreCase("y"));
    }


    @Override
    public void displayDetails() {
        System.out.println("Admin User ID: " + userID);
        System.out.println("Name: " + name);
        System.out.println("Email: " + email);
        System.out.println("Password: " + password);
        System.out.println("Role: " + role);
    }

    public static void addEmployee(String employeeID, String employeeName, String employeeEmail, String employeePassword, String employeeRole) {
        Employee employee = new Employee(employeeID, employeeName, employeeEmail, employeePassword, employeeRole);
        try (BufferedWriter writer = new BufferedWriter(new FileWriter("Employees.txt", true))) {
            String data = "\n" + employee.getUserID() + "," + employee.getName() + "," + employee.getEmail() + "," + employee.getPassword() + "," + employee.getRole();
            writer.write(data);
            writer.newLine();
            System.out.println("Employee added successfully!");
        } catch (IOException e) {
            System.out.println("Error adding employee: " + e.getMessage());
        }
    }



    public static void addSupplier(String id, String name, String email, String phone, String address, String categories) {
        Supplier supplier=new Supplier(id,name,address,phone,email,categories);
        try (BufferedWriter writer = new BufferedWriter(new FileWriter("Suppliers.txt", true))) {
            String data = "\n" + supplier.getSupplierID() + "," + supplier.getName() + "," +supplier.getEmail()+ "," + supplier.getPhone() + "," + supplier.getAddress()+","+supplier.getProductCategories();
            writer.write(data);
            writer.newLine();
            System.out.println("Supplier added successfully!");
        } catch (IOException e) {
            System.out.println("Error adding supplier: " + e.getMessage());
        }
    }
}
