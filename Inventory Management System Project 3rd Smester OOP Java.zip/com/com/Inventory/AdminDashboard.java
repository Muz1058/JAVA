package com.Inventory;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class AdminDashboard extends JFrame {

    private Admin admin;

    // Components
    private JLabel titleLabel;
    private JButton addEmployeeButton;
    private JButton removeEmployeeButton;
    private JButton viewEmployeesButton;
    private JButton addSupplierButton;
    private JButton removeSupplierButton;
    private JButton viewSuppliersButton;
    private JButton logoutButton;

    public AdminDashboard(Admin admin) {
        this.admin = admin;

        setTitle("Admin Dashboard");
        setSize(500, 400); // Increased size for better layout
        setLayout(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setResizable(false);

        // Dark theme colors
        Color backgroundColor = new Color(40, 40, 40);
        Color foregroundColor = Color.WHITE;
        Color buttonColor = new Color(60, 60, 60);

        getContentPane().setBackground(backgroundColor);

        // Initialize components
        titleLabel = new JLabel("ADMIN DASHBOARD", SwingConstants.CENTER);
        titleLabel.setFont(new Font("Arial", Font.BOLD, 24));
        titleLabel.setForeground(foregroundColor);
        titleLabel.setBounds(100, 20, 300, 40);

        // Button dimensions
        int buttonWidth = 180;
        int buttonHeight = 30;
        int xOffset = 50;
        int yOffset = 80;
        int ySpacing = 40;

        addEmployeeButton = createButton("Add Employee", xOffset, yOffset, buttonWidth, buttonHeight, e -> {
            new AddEmployeeFrame(admin);
        });

        removeEmployeeButton = createButton("Remove Employee", xOffset + buttonWidth + xOffset/2 , yOffset, buttonWidth, buttonHeight, e -> {
            String employeeID = JOptionPane.showInputDialog(AdminDashboard.this, "Enter Employee ID to remove:", "Remove Employee", JOptionPane.QUESTION_MESSAGE);
            if (employeeID != null) {
                admin.removeEmployee(employeeID);
            }
        });

        viewEmployeesButton = createButton("View Employees", xOffset, yOffset + ySpacing, buttonWidth, buttonHeight, e -> {
            new ViewEmployeesFrame(admin);
        });

        addSupplierButton = createButton("Add Supplier", xOffset + buttonWidth + xOffset/2, yOffset + ySpacing, buttonWidth, buttonHeight, e -> {
            new AddSupplierFrame(admin);
        });

        removeSupplierButton = createButton("Remove Supplier", xOffset, yOffset + 2 * ySpacing, buttonWidth, buttonHeight, e -> {
            String supplierID = JOptionPane.showInputDialog(AdminDashboard.this, "Enter Supplier ID to remove:", "Remove Supplier", JOptionPane.QUESTION_MESSAGE);
            if (supplierID != null) {
                admin.removeSupplier(supplierID);
            }
        });

        viewSuppliersButton = createButton("View Suppliers", xOffset + buttonWidth + xOffset/2, yOffset + 2 * ySpacing, buttonWidth, buttonHeight, e -> {
            new ViewSuppliersFrame(admin);
        });

        logoutButton = createButton("Logout", 175, 280, 150, buttonHeight, e -> {
            dispose();
            System.exit(0);
        });

        add(titleLabel);
        add(addEmployeeButton);
        add(removeEmployeeButton);
        add(viewEmployeesButton);
        add(addSupplierButton);
        add(removeSupplierButton);
        add(viewSuppliersButton);
        add(logoutButton);

        setLocationRelativeTo(null);
        setVisible(true);
    }

    private JButton createButton(String text, int x, int y, int width, int height, ActionListener listener) {
        JButton button = new JButton(text);
        button.setBounds(x, y, width, height);
        button.setBackground(new Color(60, 60, 60));
        button.setForeground(Color.WHITE);
        button.setFocusPainted(false);
        button.addActionListener(listener);
        return button;
    }
}