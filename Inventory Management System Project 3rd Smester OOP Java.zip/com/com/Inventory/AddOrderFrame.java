package com.Inventory;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class AddOrderFrame extends JFrame {

    private JTextField orderDateField;
    private JComboBox<String> orderStatusComboBox;
    private JTextField productIDsField;
    private JTextField supplierIDField;
    private Employee employee;
    private EmployeeDashboard parentDashboard;

    public AddOrderFrame(Employee employee) {
        super("Add New Order");
        this.employee = employee;
        this.parentDashboard = parentDashboard;

        setSize(400, 300);
        setLayout(new GridLayout(5, 2, 5, 5)); // Use GridLayout for better organization
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null); // Center the frame

        // Dark theme colors
        Color backgroundColor = new Color(40, 40, 40);
        Color foregroundColor = Color.WHITE;
        Color buttonColor = new Color(60, 60, 60);

        getContentPane().setBackground(backgroundColor);

        JLabel orderDateLabel = new JLabel("Order Date (YYYY-MM-DD):");
        orderDateLabel.setForeground(foregroundColor);
        add(orderDateLabel);

        orderDateField = new JTextField();
        orderDateField.setBackground(buttonColor);
        orderDateField.setForeground(foregroundColor);
        orderDateField.setBorder(BorderFactory.createLineBorder(Color.DARK_GRAY));
        add(orderDateField);

        JLabel orderStatusLabel = new JLabel("Order Status:");
        orderStatusLabel.setForeground(foregroundColor);
        add(orderStatusLabel);

        orderStatusComboBox = new JComboBox<>(new String[]{"Pending", "Processing", "Shipped", "Delivered"});
        orderStatusComboBox.setBackground(buttonColor);
        orderStatusComboBox.setForeground(foregroundColor);
        orderStatusComboBox.setBorder(BorderFactory.createLineBorder(Color.DARK_GRAY));
        add(orderStatusComboBox);

        JLabel productIDsLabel = new JLabel("Product IDs (comma-separated):");
        productIDsLabel.setForeground(foregroundColor);
        add(productIDsLabel);

        productIDsField = new JTextField();
        productIDsField.setBackground(buttonColor);
        productIDsField.setForeground(foregroundColor);
        productIDsField.setBorder(BorderFactory.createLineBorder(Color.DARK_GRAY));
        add(productIDsField);

        JLabel supplierIDLabel = new JLabel("Supplier ID:");
        supplierIDLabel.setForeground(foregroundColor);
        add(supplierIDLabel);

        supplierIDField = new JTextField();
        supplierIDField.setBackground(buttonColor);
        supplierIDField.setForeground(foregroundColor);
        supplierIDField.setBorder(BorderFactory.createLineBorder(Color.DARK_GRAY));
        add(supplierIDField);


        JButton addOrderButton = new JButton("Add Order");
        addOrderButton.setBackground(buttonColor);
        addOrderButton.setForeground(foregroundColor);
        addOrderButton.setFocusPainted(false);
        add(addOrderButton);

        JButton cancelButton = new JButton("Cancel");
        cancelButton.setBackground(buttonColor);
        cancelButton.setForeground(foregroundColor);
        cancelButton.setFocusPainted(false);
        add(cancelButton);


        addOrderButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String orderDateStr = orderDateField.getText();
                String status = (String) orderStatusComboBox.getSelectedItem();
                String productIDs = productIDsField.getText();
                String supplierID = supplierIDField.getText();

                SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
                try {
                    Date orderDate = dateFormat.parse(orderDateStr);
                    // If parsing is successful, proceed with adding the order
                    employee.addOrder(generateOrderID(), orderDateStr, status, productIDs, supplierID);
                    JOptionPane.showMessageDialog(AddOrderFrame.this, "Order added successfully!");
                    parentDashboard.refreshOrderTable(); // Refresh the table in the main dashboard
                    dispose(); // Close the add order frame
                } catch (ParseException ex) {
                    JOptionPane.showMessageDialog(AddOrderFrame.this, "Invalid date format. Use YYYY-MM-DD.", "Error", JOptionPane.ERROR_MESSAGE);
                } catch (IOException ex) {
                    JOptionPane.showMessageDialog(AddOrderFrame.this, "Error adding order: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
                }
            }
        });

        cancelButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                dispose(); // Close the add order frame
            }
        });

        setVisible(true);
    }



    private String generateOrderID() {
        // Simple implementation: timestamp + random number (improve if needed)
        return String.valueOf(System.currentTimeMillis() + (int)(Math.random() * 1000));
    }
}