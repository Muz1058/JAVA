package com.Inventory;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class AddSupplierFrame extends JFrame {

    public AddSupplierFrame(Admin admin) {
        // Set up the frame
        setTitle("Add New Supplier");
        setSize(400, 430);
        setLayout(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        // Dark theme colors
        Color backgroundColor = new Color(40, 40, 40);
        Color foregroundColor = Color.WHITE;
        Color buttonColor = new Color(60, 60, 60);

        getContentPane().setBackground(backgroundColor);

        // Supplier details fields
        JTextField nameField = new JTextField();
        JTextField idField = new JTextField();
        JTextField contactField = new JTextField();
        JTextField addressField = new JTextField();
        JTextField emailField = new JTextField();
        JTextField productField = new JTextField();

        // Labels
        JLabel nameLabel = new JLabel("Supplier Name:");
        JLabel idLabel = new JLabel("Supplier ID:");
        JLabel contactLabel = new JLabel("Contact:");
        JLabel addressLabel = new JLabel("Address:");
        JLabel emailLabel = new JLabel("Email:");
        JLabel productLabel = new JLabel("Product Categories:");

        // Set bounds for labels and fields
        nameLabel.setBounds(50, 50, 100, 25);
        nameLabel.setForeground(foregroundColor);
        idLabel.setBounds(50, 90, 100, 25);
        idLabel.setForeground(foregroundColor);
        contactLabel.setBounds(50, 130, 100, 25);
        contactLabel.setForeground(foregroundColor);
        addressLabel.setBounds(50, 170, 100, 25);
        addressLabel.setForeground(foregroundColor);
        emailLabel.setBounds(50, 210, 100, 25);
        emailLabel.setForeground(foregroundColor);
        productLabel.setBounds(50, 250, 100, 25);
        productLabel.setForeground(foregroundColor);

        nameField.setBounds(160, 50, 200, 25);
        idField.setBounds(160, 90, 200, 25);
        contactField.setBounds(160, 130, 200, 25);
        addressField.setBounds(160, 170, 200, 25);
        emailField.setBounds(160, 210, 200, 25);
        productField.setBounds(160, 250, 200, 25);

        // Buttons
        JButton addButton = new JButton("Add Supplier");
        addButton.setBounds(100, 300, 200, 30);
        addButton.setBackground(buttonColor);
        addButton.setForeground(foregroundColor);

        addButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String name = nameField.getText();
                String id = idField.getText();
                String phone = contactField.getText();
                String email = emailField.getText();
                String address=addressField.getText();
                String productcategories = productField.getText();
                if(name.isEmpty()||id.isEmpty()||phone.isEmpty()||email.isEmpty()||address.isEmpty()||productcategories.isEmpty()){
                    JOptionPane.showMessageDialog(null, "Invalid Input: " + name, "Error", JOptionPane.ERROR_MESSAGE);
                    nameField.setText("");
                    idField.setText("");
                    contactField.setText("");
                    addressField.setText("");
                    emailField.setText("");
                    productField.setText("");
                }

                else {
                    Admin.addSupplier(id,name, email,phone,address, productcategories);
                    JOptionPane.showMessageDialog(null, "Supplier Added: " + name, "Success", JOptionPane.INFORMATION_MESSAGE);
                    // Clear fields after adding
                    nameField.setText("");
                    idField.setText("");
                    contactField.setText("");
                    addressField.setText("");
                    emailField.setText("");
                    productField.setText("");
                }
            }
        });

        // Add components to frame
        add(nameLabel);
        add(idLabel);
        add(contactLabel);
        add(addressLabel);
        add(nameField);
        add(idField);
        add(contactField);
        add(addressField);
        add(emailLabel);
        add(emailField);
        add(productLabel);
        add(productField);
        add(addButton);

        // Visible frame
        setLocationRelativeTo(null);
        setVisible(true);
    }


}
