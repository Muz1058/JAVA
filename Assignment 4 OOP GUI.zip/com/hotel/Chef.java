package com.hotel;

public class Chef extends Employee {
    private String specialization;
    private double performanceBonus;

    public Chef(String name, int age, double baseSalary, String specialization, double performanceBonus) {
        super(name, age, baseSalary);
        this.specialization = specialization;
        this.performanceBonus = performanceBonus;
    }

    @Override
    public double calculateSalary() {
        return baseSalary + performanceBonus;
    }
}
