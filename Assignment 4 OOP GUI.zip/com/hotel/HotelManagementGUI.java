package com.hotel;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

public class HotelManagementGUI extends JFrame
{

    private Hotel hotel;

    private  JLabel  titleLabel;
    private JButton addEmployeeButton;
    private JButton viewEmployeesButton;
    private JButton calculateSalaryButton;
    private JButton viewRevenueButton;
    private JButton logoutButton;

    public HotelManagementGUI(Hotel hotel)
    {
        this.hotel = hotel;

        setTitle("Hotel Management Dashboard");
        setSize(500, 400);
        setLayout(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setResizable(false);

        Color backgroundColor = new Color(40, 40, 40);
        Color foregroundColor = Color.WHITE;
        Color buttonColor = new Color(60, 60, 60);

        getContentPane().setBackground(backgroundColor);

        titleLabel = new JLabel("HOTEL MANAGEMENT", SwingConstants.CENTER);
        titleLabel.setFont(new Font("Arial", Font.BOLD, 24));
        titleLabel.setForeground(foregroundColor);
        titleLabel.setBounds(100, 20, 300, 40);

        int Width = 180;
        int Height = 30;
        int x = 50;
        int y = 80;
        int ySpacing = 50;

        addEmployeeButton = createButton("Add Employee", x, y, Width, Height, e -> {
            new AddEmployeeFrame(hotel);
        });

        viewEmployeesButton = createButton("View Employees", x + Width + x / 2, y, Width,Height, e -> {
            new ViewEmployeesFrame(hotel);
        });

        calculateSalaryButton = createButton("Calculate Salary", x, y + ySpacing, Width, Height, e -> {
            new CalculateSalaryFrame(hotel);
        });

        viewRevenueButton = createButton("View Revenue", x + Width + x / 2, y + ySpacing, Width, Height, e -> {
            double revenue = hotel.generateRevenue();
            JOptionPane.showMessageDialog(this, "Total Revenue: " + revenue+"$");
        });

        logoutButton = createButton("Logout", 175, 240, 150, Height, e -> {
            dispose();
            System.exit(0);
        });

        add(titleLabel);
        add(addEmployeeButton);
        add(viewEmployeesButton);
        add(calculateSalaryButton);
        add(viewRevenueButton);
        add(logoutButton);

        setLocationRelativeTo(null);
        setVisible(true);
    }

    private JButton createButton(String text, int x, int y, int width, int height, ActionListener listener)
    {
        JButton button = new JButton(text);
        button.setBounds(x, y, width, height);
        button.setBackground(new Color(60, 60, 60));
        button.setForeground(Color.WHITE);
        button.setFocusPainted(false);
        button.addActionListener(listener);


        return button;
    }

    public static void main(String[] args)
    {
        Hotel hotel = new Hotel("Grand Hotel", "New York");
        new HotelManagementGUI(hotel);
    }
}
