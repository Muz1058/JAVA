package com.hotel;

public class SeniorManager extends Manager {
    private double decisionMakingBonus;

    public SeniorManager(String name, int age, double baseSalary, double bonus, double decisionMakingBonus) {
        super(name, age, baseSalary, bonus);
        this.decisionMakingBonus = decisionMakingBonus;
    }

    @Override
    public double calculateSalary() {
        return super.calculateSalary() + decisionMakingBonus;
    }
}
