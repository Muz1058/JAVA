package com.hotel;

public interface Revenue {
    double generateRevenue();
}
