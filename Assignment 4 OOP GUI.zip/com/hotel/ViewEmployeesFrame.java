package com.hotel;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;

public class ViewEmployeesFrame extends JFrame {
    public ViewEmployeesFrame(Hotel hotel) {
        setTitle("Employee List");
        setSize(600, 400);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLayout(new BorderLayout());

        String[] columns = {"Name", "Age", "Base Salary", "Final Salary"};
        DefaultTableModel tableModel = new DefaultTableModel(columns, 0);
        JTable employeeTable = new JTable(tableModel);
        employeeTable.setBackground(new Color(60, 60, 60));
        employeeTable.setForeground(Color.WHITE);
        employeeTable.getTableHeader().setBackground(new Color(40, 40, 40));
        employeeTable.getTableHeader().setForeground(Color.WHITE);

        for (Employee e : hotel.employeeList) {
            tableModel.addRow(new Object[]{e.getName(), e.age, e.baseSalary, e.calculateSalary()});
        }

        JScrollPane scrollPane = new JScrollPane(employeeTable);
        add(scrollPane, BorderLayout.CENTER);

        JButton closeButton = new JButton("Close");
        closeButton.setBackground(new Color(60, 60, 60));
        closeButton.setForeground(Color.WHITE);
        closeButton.addActionListener(e -> {
            dispose();
            new HotelManagementGUI(hotel);
        });

        JPanel buttonPanel = new JPanel();
        buttonPanel.setBackground(new Color(40, 40, 40));
        buttonPanel.add(closeButton);

        add(buttonPanel, BorderLayout.SOUTH);

        setLocationRelativeTo(null);
        setVisible(true);

    }
}
