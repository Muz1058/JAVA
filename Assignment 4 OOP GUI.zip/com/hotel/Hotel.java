package com.hotel;

import java.util.ArrayList;

public class Hotel implements Revenue {
    private String hotelName;
    private String location;
    ArrayList<Employee> employeeList;

    public Hotel(String hotelName, String location) {
        this.hotelName = hotelName;
        this.location = location;
        this.employeeList = new ArrayList<>();
    }

    public String getHotelName() {
        return hotelName;
    }

    public void setHotelName(String hotelName) {
        this.hotelName = hotelName;
    }

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    public ArrayList<Employee> getEmployeeList() {
        return employeeList;
    }

    public void setEmployeeList(ArrayList<Employee> employeeList) {
        this.employeeList = employeeList;
    }

    public void addEmployee(Employee employee) {
        for (Employee e : employeeList) {
            if (e.getName().equalsIgnoreCase(employee.getName())) {
                System.out.println("Employee with this name already exists.");
                return;
            }
        }
        employeeList.add(employee);
    }

    public void displayEmployees() {
        for (Employee e : employeeList) {
            System.out.println(e.getDetails());
        }
    }

    @Override
    public double generateRevenue() {
        return employeeList.size() * 5000; // Fixed revenue per employee
    }
}
