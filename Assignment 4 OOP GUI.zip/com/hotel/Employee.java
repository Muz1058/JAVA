package com.hotel;

public abstract class Employee {
    protected String name;
    protected int age;
    protected double baseSalary;

    public Employee(String name, int age, double baseSalary) {
        this.name = name;
        this.age = age;
        this.baseSalary = baseSalary;
    }

    public abstract double calculateSalary(); // Abstract method for polymorphism

    public String getDetails() {
        return "Name: " + name + ", Age: " + age + ", Base Salary: $" + baseSalary;
    }

    public String getName() {
        return name;
    }
}
