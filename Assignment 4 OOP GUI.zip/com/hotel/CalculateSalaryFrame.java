package com.hotel;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

public class CalculateSalaryFrame extends JFrame {

    public CalculateSalaryFrame(Hotel hotel) {
        // Set up the frame
        setTitle("Calculate Employee Salary");
        setSize(400, 250);
        setLayout(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        // Dark theme colors
        Color backgroundColor = new Color(40, 40, 40);
        Color foregroundColor = Color.WHITE;
        Color buttonColor = new Color(60, 60, 60);

        getContentPane().setBackground(backgroundColor);

        JTextField nameField = new JTextField();
        JLabel nameLabel = new JLabel("Employee Name:");

        JTextArea resultArea = new JTextArea();
        resultArea.setEditable(false);
        resultArea.setBackground(backgroundColor);
        resultArea.setForeground(foregroundColor);

        nameLabel.setBounds(50, 50, 120, 25);
        nameLabel.setForeground(foregroundColor);
        nameField.setBounds(180, 50, 180, 25);

        JButton calculateButton = new JButton("Calculate Salary");
        calculateButton.setBounds(100, 100, 200, 30);
        calculateButton.setBackground(buttonColor);
        calculateButton.setForeground(foregroundColor);

        calculateButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String name = nameField.getText();
                boolean found = false;

                for (Employee emp : hotel.getEmployeeList()) {
                    if (emp.getName().equalsIgnoreCase(name)) {
                        resultArea.setText("Salary of " + name + ": " + emp.calculateSalary()+"$");
                        found = true;
                        break;
                    }
                }

                if (!found) {
                    resultArea.setText("Employee not found!");
                }
            }
        });

        // Result TextArea
        resultArea.setBounds(50, 150, 300, 40);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent e) {
                new HotelManagementGUI(hotel);
            }
        });

        add(nameLabel);
        add(nameField);
        add(calculateButton);
        add(resultArea);

        setLocationRelativeTo(null);
        setVisible(true);
    }
}
