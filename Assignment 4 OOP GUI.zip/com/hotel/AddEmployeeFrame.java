package com.hotel;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

public class AddEmployeeFrame extends JFrame {

    public AddEmployeeFrame(Hotel hotel) {

        setTitle("Add New Employee");
        setSize(400, 500);
        setLayout(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        Color backgroundColor = new Color(40, 40, 40);
        Color foregroundColor = Color.WHITE;
        Color buttonColor = new Color(60, 60, 60);

        getContentPane().setBackground(backgroundColor);

        JTextField nameField = new JTextField();
        JTextField ageField = new JTextField();
        JTextField idField = new JTextField();
        JTextField salaryField = new JTextField();

        JLabel nameLabel = new JLabel("Name:");
        JLabel ageLabel = new JLabel("Age:");
        JLabel idLabel = new JLabel("Employee ID:");
        JLabel salaryLabel = new JLabel("Base Salary:");
        JLabel positionLabel = new JLabel("Position:");
        JLabel extraLabel = new JLabel("Additional Info:");

        String[] positions = {"Manager", "HousekeepingStaff", "Chef", "SeniorManager"};
        JComboBox<String> positionComboBox = new JComboBox<>(positions);
        positionComboBox.setBackground(buttonColor);
        positionComboBox.setForeground(Color.WHITE);

        JTextField extraField = new JTextField();

        nameLabel.setBounds(50, 50, 120, 25);
        nameLabel.setForeground(foregroundColor);
        nameField.setBounds(180, 50, 160, 25);

        ageLabel.setBounds(50, 90, 120, 25);
        ageLabel.setForeground(foregroundColor);
        ageField.setBounds(180, 90, 160, 25);

        idLabel.setBounds(50, 130, 120, 25);
        idLabel.setForeground(foregroundColor);
        idField.setBounds(180, 130, 160, 25);

        salaryLabel.setBounds(50, 170, 120, 25);
        salaryLabel.setForeground(foregroundColor);
        salaryField.setBounds(180, 170, 160, 25);

        positionLabel.setBounds(50, 210, 120, 25);
        positionLabel.setForeground(foregroundColor);
        positionComboBox.setBounds(180, 210, 160, 25);

        extraLabel.setBounds(50, 250, 120, 25);
        extraLabel.setForeground(foregroundColor);
        extraField.setBounds(180, 250, 160, 25);

        positionComboBox.addActionListener(e -> {
            String selected = (String) positionComboBox.getSelectedItem();
            if (selected.equals("Manager") || selected.equals("SeniorManager")) {
                extraLabel.setText("Bonus:");
            } else if (selected.equals("HousekeepingStaff")) {
                extraLabel.setText("Hours Worked:");
            } else if (selected.equals("Chef")) {
                extraLabel.setText("Specialization:");
            }
        });

        JButton addButton = new JButton("Add Employee");
        addButton.setBounds(100, 310, 200, 30);
        addButton.setBackground(buttonColor);
        addButton.setForeground(foregroundColor);

        addButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Get input values
                String name = nameField.getText();
                String id = idField.getText();
                int age;
                double baseSalary;

                try {
                    age = Integer.parseInt(ageField.getText());
                    baseSalary = Double.parseDouble(salaryField.getText());
                } catch (NumberFormatException ex) {
                    JOptionPane.showMessageDialog(null, "Invalid age or salary input. Please enter numeric values.", "Error", JOptionPane.ERROR_MESSAGE);
                    return;
                }

                String position = (String) positionComboBox.getSelectedItem();
                Employee employee = null;

                try {
                    if (position.equals("Manager"))
                    {
                        double bonus = Double.parseDouble(extraField.getText());
                        employee = new Manager(name, age, baseSalary, bonus);
                    }
                    else if (position.equals("HousekeepingStaff"))
                    {
                        int hoursWorked = Integer.parseInt(extraField.getText());
                        employee = new HousekeepingStaff(name, age, baseSalary, hoursWorked, 15); // Assuming $15 per hour
                    }
                    else if (position.equals("Chef"))
                    {
                        String specialization = extraField.getText();
                        employee = new Chef(name, age, baseSalary, specialization, 2000); // Assuming $2000 bonus
                    }
                    else if (position.equals("SeniorManager"))
                    {
                        double bonus = Double.parseDouble(extraField.getText());
                        employee = new SeniorManager(name, age, baseSalary, bonus, 5000); // Extra bonus
                    }

                    hotel.addEmployee(employee);
                    JOptionPane.showMessageDialog(null, "Employee Added: " + name, "Success", JOptionPane.INFORMATION_MESSAGE);

                    nameField.setText("");
                    ageField.setText("");
                    idField.setText("");
                    salaryField.setText("");
                    extraField.setText("");

                } catch (NumberFormatException ex)
                {
                    JOptionPane.showMessageDialog(null, "Invalid number input. Please enter a valid number.", "Error", JOptionPane.ERROR_MESSAGE);
                }
            }
        });


        add(nameLabel);
        add(nameField);
        add(ageLabel);
        add(ageField);
        add(idLabel);
        add(idField);
        add(salaryLabel);
        add(salaryField);
        add(positionLabel);
        add(positionComboBox);
        add(extraLabel);
        add(extraField);
        add(addButton);

        setLocationRelativeTo(null);
        setVisible(true);
    }
}
