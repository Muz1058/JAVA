package com.hotel;

public class HousekeepingStaff extends Employee {
    private int hoursWorked;
    private double hourlyRate;

    public HousekeepingStaff(String name, int age, double baseSalary, int hoursWorked, double hourlyRate) {
        super(name, age, baseSalary);
        this.hoursWorked = hoursWorked;
        this.hourlyRate = hourlyRate;
    }

    @Override
    public double calculateSalary() {
        return baseSalary + (hoursWorked * hourlyRate);
    }
}
