import java.util.ArrayList;
import java.util.List;
class Book {
    private String title;
    private String author;

    public Book(String title, String author) {
        this.title = title;
        this.author = author;
    }
    public void displayBookInfo() {
        System.out.println("Title: " + title + ", Author: " + author);
    }
}
class Library {
    private List<Book> books;


    public Library() {
        this.books = new ArrayList<>();
    }

    public void addBook(Book book) {
        books.add(book);
    }


    public void displayLibraryInfo() {
        System.out.println("Library Information:");
        if (books.isEmpty()) {
            System.out.println("No books in the library.");
        } else {
            int index = 1;
            for (Book book : books) {
                System.out.print("Book " + index + ": ");
                book.displayBookInfo();
                index++;
            }
        }
    }
}


public class Task2_Implementing_Aggregation {
    public static void main(String[] args) {
        Book book1 = new Book("1984", "George Orwell");
        Book book2 = new Book("To Kill a Mockingbird", "Harper Lee");
        Book book3 = new Book("The Great Gatsby", "F. Scott Fitzgerald");
        Library library = new Library();

        library.addBook(book1);
        library.addBook(book2);
        library.addBook(book3);
        library.displayLibraryInfo();
    }
}




