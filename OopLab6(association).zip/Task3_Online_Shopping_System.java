import java.util.ArrayList;
import java.util.List;


class Product {
    private int productId;
    private String productName;
    private double price;


    public Product(int productId, String productName, double price) {
        this.productId = productId;
        this.productName = productName;
        this.price = price;
    }

    public String getProductName() {
        return productName;
    }

    public double getPrice() {
        return price;
    }
}


class Order {
    private int orderId;
    private String orderDate;
    private List<Product> products;


    public Order(int orderId, String orderDate) {
        this.orderId = orderId;
        this.orderDate = orderDate;
        this.products = new ArrayList<>();
    }

    public void addProduct(Product product) {
        products.add(product);
    }

    public void displayOrderInfo() {
        System.out.println("Order ID: " + orderId + ", Order Date: " + orderDate);
        System.out.println("Products in the Order:");
        for (Product product : products) {
            System.out.println("- " + product.getProductName() + " ($" + product.getPrice() + ")");
        }
    }
}


class Customer {
    private int customerId;
    private String customerName;
    private List<Order> orders;


    public Customer(int customerId, String customerName) {
        this.customerId = customerId;
        this.customerName = customerName;
        this.orders = new ArrayList<>();
    }

    public void placeOrder(Order order) {
        orders.add(order);
    }

    public void viewOrderHistory() {
        System.out.println("Customer: " + customerName + " (ID: " + customerId + ")");
        System.out.println("Order History:");
        for (Order order : orders) {
            order.displayOrderInfo();
        }
    }
}

class ShoppingCart {
    private List<Product> cartItems;

    public ShoppingCart() {
        this.cartItems = new ArrayList<>();
    }

    public void addItem(Product product) {
        cartItems.add(product);
    }

    public void removeItem(Product product) {
        cartItems.remove(product);
    }

    public double getTotalPrice() {
        double total = 0;
        for (Product product : cartItems) {
            total += product.getPrice();
        }
        return total;
    }

    public void displayCart() {
        System.out.println("Shopping Cart:");
        for (Product product : cartItems) {
            System.out.println("- " + product.getProductName() + " ($" + product.getPrice() + ")");
        }
    }
}

public class Task3_Online_Shopping_System {
    public static void main(String[] args) {
        Product product1 = new Product(1, "Laptop", 1000.00);
        Product product2 = new Product(2, "Mouse", 20.00);
        Product product3 = new Product(3, "Keyboard", 50.00);


        Order order1 = new Order(101, "2024-11-17");
        order1.addProduct(product1);
        order1.addProduct(product2);

        Order order2 = new Order(102, "2024-11-18");
        order2.addProduct(product3);


        Customer customer = new Customer(1, "Hamza");
        customer.placeOrder(order1);
        customer.placeOrder(order2);

        customer.viewOrderHistory();
        ShoppingCart cart = new ShoppingCart();
        cart.addItem(product1);
        cart.addItem(product3);
        cart.displayCart();
        System.out.println("Total Price: $" + cart.getTotalPrice());
    }
}
