import java.util.ArrayList;
import java.util.List;

class Room{
    private String type;
    private int area;

    public Room(){
        this.type="----";
        this.area=0;
    }
    public Room(String type,int area) {
        this.type = type;
        this.area = area;
    }

    public void displayRoomInfo() {
        System.out.println("Room Type: " + type + ", Area: " + area + " sqm");
    }
}
class House{
    private  List<Room>rooms;

    public House() {
        this.rooms=new ArrayList<>();
    }

    public void addRoom(Room room){
       rooms.add(room);
    }

    public void displayHouseInfo() {
        System.out.println("House Information:");
        if (rooms.isEmpty()) {
            System.out.println("No rooms in the house.");
        } else {
            int index = 1;
            for (Room room : rooms) {
                System.out.println("Room " + index + ":");
                room.displayRoomInfo();
                index++;
            }
        }
    }
}

public class Task1_Implementing_Composition {
    public static void main(String[] args) {
       House house=new House();
        house.addRoom(new Room("Bedroom", 120));
        house.addRoom(new Room("Kitchen", 80));
        house.addRoom(new Room("Living Room", 200));
        house.displayHouseInfo();
    }
}
