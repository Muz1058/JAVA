import java.util.Scanner;

public class task2 {
    public static void main(String[] args) {
        Scanner obj=new Scanner(System.in);
        System.out.print("Enter Number of Rows :");
        int row=obj.nextInt();
        System.out.print("Enter Number of Cols :");
        int col=obj.nextInt();
        int [][]arr= new int [row][col];
        for(int i=0;i<row;i++)
        {
            for(int j=0;j<col;j++)
            {
                System.out.print("Enter number at ["+ i +"]["+ j+"] :");
                arr[i][j]= obj.nextInt();
            }
        }
        System.out.println("Transpose of Matrix ");
        for(int i=0;i<col;i++)
        {
            for(int j=0;j<row;j++)
            {
                System.out.print(arr[j][i]+ " ");
            }
            System.out.println();
        }
     }
}
