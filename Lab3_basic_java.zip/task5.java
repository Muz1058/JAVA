import java.util.Scanner;

public class task5 {
    public static void main(String[] args) {
        Scanner obj=new Scanner(System.in);
        System.out.print("Enter a String : ");
        String str1=obj.nextLine();
        String str=str1.toLowerCase();

        for (int i = 0; i < str.length(); i++) {
            byte count=0;
            for (int j = i; j <str.length() ; j++) {
                if(str.charAt(i)==str.charAt(j))
                {
                    count++;
                }
            }
            if(count==1)
            {
                System.out.println("The First non-repeating char : " + str.charAt(i));
                return;
            }
        }
    }
}
