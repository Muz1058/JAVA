import java.util.Scanner;
public class task4 {
    public static boolean isMagicSquare(int[][] square)
    {
        int n = square.length;

        int magicSum = 0;
        for (int j = 0; j < n; j++) {
            magicSum += square[0][j];
        }
        for (int i = 0; i < n; i++)
        {
            int rowSum = 0;
            for (int j = 0; j < n; j++)
            {
                rowSum += square[i][j];
            }
            if (rowSum != magicSum)
            {
                return false;
            }
        }
        for (int j = 0; j < n; j++)
        {
            int colSum = 0;
            for (int i = 0; i < n; i++)
            {
                colSum += square[i][j];
            }
            if (colSum != magicSum)
            {
                return false;
            }
        }
        int diagonalSum1 = 0;
        for (int i = 0; i < n; i++)
        {
            diagonalSum1 += square[i][i];
        }
        if (diagonalSum1 != magicSum)
        {
            return false;
        }
        int diagonalSum2 = 0;
        for (int i = 0; i < n; i++)
        {
            diagonalSum2 += square[i][n - 1 - i];
        }
        if (diagonalSum2 != magicSum)
        {
            return false;
        }
        return true;
    }

    public static void main(String[] args) {
        Scanner obj=new Scanner(System.in);
        System.out.print("Enter the Size of Matrix (N*N) :");
        int size=obj.nextInt();
        int [][]square= new int [size][size];
        for(int i=0;i<size;i++)
        {
            for(int j=0;j<size;j++)
            {
                System.out.print("Enter number at ["+ i +"]["+ j+"] :");
                square[i][j]= obj.nextInt();
            }
        }
        if (isMagicSquare(square))
        {
            System.out.println("\nThe Matrix is a magic square.");
        }
        else
        {
            System.out.println("\nThe Matrix is not a magic square.");
        }
    }
}