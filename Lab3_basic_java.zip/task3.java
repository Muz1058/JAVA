import java.util.ArrayList;

public class task3 {
    public static void main(String[] args) {
        ArrayList<String> input=new ArrayList<>();
        input.add("Jabbar");
        input.add("Ali");
        input.add("Babar");
        input.add("Danish");
        input.add("Aslam");
        System.out.println("ArrayList : "+ input);
        System.out.println("Second name :"+ input.get(1));
        System.out.println("Fourth name :"+ input.get(3));
        input.set(2,"Suleman");
        System.out.println("ArrayList after replacing 3rd name : "+ input);
        input.removeFirst();
        System.out.println("ArrayList after Removing First: "+ input);
        System.out.println("Size of ArrayList : "+ input.size());
        System.out.println("Is Ali in ArrayList : "+ input.contains("Ali"));
        System.out.println("Final ArrayList : "+ input);



}
}
