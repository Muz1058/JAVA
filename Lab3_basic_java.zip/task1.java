import java.util.Scanner;

public class task1 {
    public static void main(String[] args) {

        Scanner obj=new Scanner(System.in);
        System.out.print("Enter Number of Elements Of Array :");
        int num=obj.nextInt();
        int []arr= new int [num];
        for(int i=0;i<num;i++)
        {
            System.out.print("Enter number at index :"+ i+1 +" :");
            arr[i]=obj.nextInt();
        }
        System.out.print("Duplicates Numbers Are :"        );
        for(int i=0;i<num;i++)
        {
            int count=0;
            for (int j=i;j<num;j++)
            {
                if(arr[i]==arr[j])
                {
                    count++;
                }
            }
            if(count==2)
            {
                System.out.print(arr[i]+  " ");
            }
        }
    }
}
