import java.util.ArrayList;
import java.util.Scanner;
public class ScenerioLab3 {
    public static void main(String[] args) {
        Scanner obj=new Scanner(System.in);
        ArrayList <Integer> list=new ArrayList<>();
        list.add(0);
        list.add(50);
        list.add(75);
        list.add(100);
        list.add(25);
        System.out.println("Initial Brightness Level :");
        int count=1;
        for(int i:list)
        {
            System.out.println("Light "+ (count++) +" : "+i+ "%");
        }
        list.clear();
        System.out.println("\nModify Brightness Level (Enter new value) : ");
        int inputToModify;
        for(int i=0;i<5;i++){
            System.out.print("Enter Brightness for Light "+(i+1) +" : ");
            inputToModify=obj.nextInt();
            if(inputToModify>100)
            {
                System.out.println("Warning: Brightness set to 100% (Maximum)");
                inputToModify=100;
            }
            else if(inputToModify<0)
            {
                System.out.println("Warning: Brightness set to 0% (Minimum)");
                inputToModify=0;
            }
            list.add(inputToModify);
        }


        System.out.print("\n\nDo you want to remove any light's brightness leve? (yes/no) :");
        String askToRemove;
        askToRemove=obj.next();

        if(askToRemove.equals("yes")||askToRemove.equals("Yes")||askToRemove.equals("YES"))
        {
            System.out.print("Enter the light number to remove : ");
            int inputToRemove=obj.nextInt();
            list.remove(inputToRemove-1);
        }

        System.out.println("Updated Brightness Level :");
        count=1;
        for(int i:list)
        {
            System.out.println("Light "+ (count++) +" : "+i+ "%");
        }

        String mode="Energy Saving Mode";
        System.out.println("Smart light mode : "+ mode);
        System.out.println("Length of mode : "+mode.length());
        System.out.println("Mode in UpperCase :"+mode.toUpperCase());
        System.out.println("Mode in LowerCAse : "+ mode.toLowerCase() );
        System.out.println("First word of mode : "+mode.substring(0,6));
        System.out.println("Updated mode : "+ mode.replace("Energy","Efficiency"));
        System.out.println("\n\n\nFinal configuration of Smart Light Controller :\nBrightness Level (Final)");
        count=1;
        for(int i:list)
        {
            System.out.println("Light "+ (count++) +" : "+i+ "%");
        }
        System.out.println("Current Mode :"+mode);
        System.out.println("Smart Light Controller Configured Successfully!");
    }
}
