public class task6 {
    public static void main(String[] args) {
        String str="java is awesome";
        char []arr=str.toCharArray();

        if(arr[0]>='a' && arr[0]<='z')
        {
            arr[0]-=32;
            //arr[0]=Character.toUpperCase(arr[0]);
        }
        for (int i = 1; i < arr.length-1; i++) {
            if(arr[i]==' ')
            {
                if(arr[i+1]>='a' && arr[i+1]<='z')
                {
                    arr[i+1]-=32;
                   // arr[i+1]=Character.toUpperCase(arr[i+1]);
                }
            }
        }
        System.out.println(arr);
    }
}
