import java.util.ArrayList;

class Team {
    private String teamName;
    private ArrayList<Player> players;

    public Team() {
        teamName = "undefined";
        players = new ArrayList<>();
    }

    public Team(String teamName) {
        this.teamName = teamName;
        players = new ArrayList<>();
    }

    public void addPlayer(Player player) {
        players.add(player);
        player.setTeam(this);
    }

    public ArrayList<Player> getPlayers() {
        return players;
    }

    public String getTeamName() {
        return teamName;
    }

    public String toString() {
        return "\nTeam{" +
                "\nteamName='" + teamName + '\'' +
                ",\n players=" + players +
                '}';
    }
}

class Player {
    private String name;
    private Team team;

    public Player() {
        name = "undefined";
    }

    public Player(String name) {
        this.name = name;
    }

    public void setTeam(Team team) {
        this.team = team;
    }

    public String getTeamName() {
        return team != null ? team.getTeamName() : "No Team";
    }

    public String toString() {
        return "\nPlayer{" +
                "name='" + name + '\'' +
                ", team=" + (team != null ? team.getTeamName() : "No Team") +
                '}';
    }
}

public class Main {
    public static void main(String[] args) {
        Player player1 = new Player("Babar");
        Player player2 = new Player("Shaheen");
        Player player3 = new Player("Haris Rauf");
        Player player4 = new Player("Fakhar");
        Player player5 = new Player("Saim");

        Team LQ = new Team("Lahore Qalandars");
        LQ.addPlayer(player2);
        LQ.addPlayer(player3);
        LQ.addPlayer(player4);

        Team Zalmi = new Team("Peshawar Zalmi");
        Zalmi.addPlayer(player1);
        Zalmi.addPlayer(player5);

        System.out.println(LQ);
        System.out.println(Zalmi);
    }
}
