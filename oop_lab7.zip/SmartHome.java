import java.io.IOException;
import java.io.*;
class Home{
    private int bedrooms;
    private int bathrooms;
    private String additionalFeatures;

    public Home(){
        bedrooms=0;
        bathrooms=0;
        additionalFeatures="----";
    }

    public Home(int bedrooms, int bathrooms, String additionalFeatures) {
        this.bedrooms = bedrooms;
        this.bathrooms = bathrooms;
        this.additionalFeatures = additionalFeatures;
    }

    public int getBedrooms() {
        return bedrooms;
    }

    public void setBedrooms(int bedrooms) {
        this.bedrooms = bedrooms;
    }

    public int getBathrooms() {
        return bathrooms;
    }

    public void setBathrooms(int bathrooms) {
        this.bathrooms = bathrooms;
    }

    public String getAdditionalFeatures() {
        return additionalFeatures;
    }

    public void setAdditionalFeatures(String additionalFeatures) {
        this.additionalFeatures = additionalFeatures;
    }

    @Override
    public String toString() {
        return "Home{" +
                "bedrooms=" + bedrooms +
                ", bathrooms=" + bathrooms +
                ", additionalFeatures='" + additionalFeatures + '\'' +
                '}';
    }
}


public class SmartHome {
    public static void main(String[] args)throws IOException {

        String filename="Home.txt";
        File home=new File(filename);
        if (home.createNewFile()){
            System.out.println("File create Successfully");
        }
        else {
            System.out.println("File already exists");
        }
        FileWriter fw=new FileWriter(filename);
        BufferedWriter bw=new BufferedWriter(fw);
        bw.write(1);
        bw.write(",");


    }
}
