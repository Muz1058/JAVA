import java.io.*;
class Book {
    private String title;
    private String author;
    private float price;

    public Book(){
        title="----";
        author="----";
        price=0.0f;
    }
    public Book(String tit,String au,float pri){
        title=tit;
        author=au;
        price=pri;
    }
    public Book(Book obj){
        this.title= obj.title;
        this.author=obj.author;
        this.price= obj.price;
    }
    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }
    public String getAuthor() {
        return author;
    }

    public void setAuthor(String author) {
        this.author = author;
    }

    public float getPrice() {
        return price;
    }

    public void setPrice(float price) {
        this.price = price;
    }

    @Override
    public String toString() {
        return "book title:"+title+"book author:"+author+"book price:"+price;
    }
}
 class Member {
    private String member_name;
    private String member_id;
    private String contact_no;

    public Member(){
        member_name="-----";
        member_id="-----";
        contact_no="-----";
    }
    public Member(String m_name,String m_id,String contact_nu){
        member_name=m_name;
        member_id=m_id;
        contact_no=contact_nu;
    }
    public Member(Member obj){
        this.member_name=obj.member_name;
        this.member_id=obj.member_id;
        this.contact_no= obj.contact_no;
    }

    public String getMember_name() {
        return member_name;
    }

    public void setMember_name(String member_name) {
        this.member_name = member_name;
    }

    public String getMember_id() {
        return member_id;
    }

    public void setMember_id(String member_id) {
        this.member_id = member_id;
    }

    public String getContact_no() {
        return contact_no;
    }

    public void setContact_no(String contact_no) {
        this.contact_no = contact_no;
    }

    @Override
    public String toString() {
        return "Member name:"+member_name+"member id:"
                +member_id+"member contact number:"+contact_no;
    }
}
class LibraryTransaction {
    private Book book;
    private Member member;
    private int transcationDate;


    public LibraryTransaction(){
        book=new Book();
        member=new Member();
        transcationDate=0;
    }

    public LibraryTransaction(Book b,Member m,int trans_date){
        book=new Book(b);
        member=new Member(m);
        transcationDate=trans_date;
    }
    public LibraryTransaction(LibraryTransaction obj){
        this.book=new Book(obj.book);
        this.member=new Member(obj.member);
        this.transcationDate=obj.transcationDate;
    }

    public Book getBook() {
        return book;
    }

    public void setBook(Book book) {
        this.book = book;
    }

    public Member getMember() {
        return member;
    }

    public void setMember(Member member) {
        this.member = member;
    }

    public int getTranscationDate() {
        return transcationDate;
    }

    public void setTranscationDate(int transcationDate) {
        this.transcationDate = transcationDate;
    }

    @Override
    public String toString() {
        return "Book info:"+book+"Member info:"+"transcation date:"+transcationDate;
    }
}


public class Main {
    public static void main(String[] args) {
        Book b1=new Book("Story of women","jord deven",1500f);
        Member m1=new Member("Ansir ali","542","0342643857");
        LibraryTransaction transaction=new LibraryTransaction(b1,m1,5/7/2022);
        System.out.println(b1);
        System.out.println(m1);
        System.out.println(transaction);
        File obj=new File("library_data.txt");
        try {
            if(obj.createNewFile()){
                System.out.println("file is created");
            }
            else{
                System.out.println("file is already created:");
                BufferedReader BR=new BufferedReader(new FileReader(obj));
                String line;
                while ((line=BR.readLine())!=null){
                    System.out.println(line);
                }
            }
            BufferedWriter BW=new BufferedWriter(new FileWriter(obj,true));
            BW.write(b1.toString());
            BW.newLine();
            BW.write(m1.toString());
            BW.newLine();
            BW.write(transaction.toString());
            BW.close();
        } catch (IOException e) {
            throw new RuntimeException(e);
        }

    }
}