//import java.io.*;
//
//public class FileReadingDemo {
//    public static void main(String[] args) {
//        String filename="example.txt";
//        try(BufferedReader reader=new BufferedReader(new FileReader(filename))){
//            String line[];
////            while((line[i]=reader.read)!=null){
//                System.out.println(line);
//
//            }
//
//        }
//        catch (IOException e){
//            System.out.println("An error occurred while reading from File");
//            e.printStackTrace();
//        }
//    }
//}
